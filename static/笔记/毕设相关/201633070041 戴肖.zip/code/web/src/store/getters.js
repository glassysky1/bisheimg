export default{
  refreshCartListFlag(state){
    return state.refreshCartListFlag
  }
}