export default{
  refreshCartListFlag:true
}